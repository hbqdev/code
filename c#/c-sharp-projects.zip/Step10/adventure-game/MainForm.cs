using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using game.gameclasses;


namespace game {
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public partial class MainForm : Form {
        Adventure adv; // the Adventure object


        public MainForm( ) {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent( );
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main( ) {
            Application.Run( new MainForm( ) );
        }

        private void Wr( String s ) {
            // utility method to append text to textbox
            displayTB.AppendText( s );
        }

        private void WrLn( String s ) {
            // simple utility method that appends carriage-return/linefeed before caling Wr()
            Wr( s );
            Wr( "\r\n" );
        }

        private void initAdventure( ) {
            // create adventure and describe current room
            adv = new Adventure( );
            displayTB.Clear( );
            doLook( );
        }

        private void showLocation( ) {
            Wr( adv.Player.Name );
            Wr( " are currently in this room: " );
            WrLn( adv.Player.CurrentRoom.describe( ) );
        }

        private void showInventory( ) {
            WrLn( "You have " + adv.Player.Things.describe( ) );
        }

        private void testBtn_Click( object sender, System.EventArgs e ) {
            // an example of creating a file open dialog in code
            Stream st;
            OpenFileDialog openFileDialog1 = new OpenFileDialog( );

            openFileDialog1.InitialDirectory = ".";
            openFileDialog1.Filter = "sav files (*.sav)|*.sav|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if( openFileDialog1.ShowDialog( ) == DialogResult.OK ) {
                if( ( st = openFileDialog1.OpenFile( ) ) != null ) {
                    // File loading code would be added here
                    st.Close( );
                }
            }

        }

        private void movePlayer( Dir aDir ) {
            if( adv.movePlayerTo( aDir ) == Msg.NOEXIT )
                WrLn( Msg.NOEXIT + "!" );
            else
                WrLn( adv.Player.CurrentRoom.describe( ) );
        }

        private void transferOb( Thing t, ThingList fromlist, ThingList tolist ) {
            fromlist.Remove( t );
            tolist.Add( t );
        }

        private string takeOb( string obname ) {
            Thing t = adv.Player.CurrentRoom.Things.thisOb( obname );
            if( obname == "" ) {
                obname = "nameless object"; // if no object specified
            }
            if( t == null )
                return "There is no " + obname + " here!";
            else {
                if( t.CanTake ) {
                    transferOb( t, adv.Player.CurrentRoom.Things, adv.Player.Things );
                    return t.Name + " taken!";
                } else
                    return "You can't take the " + t.Name + "!";
            }
        }

        private string dropObSpecialAction( Thing t, Room r ) {
            if( ( t.Name == "carrot" ) && ( r.Name == "Kennel Room" ) ) {
                // TODO: Create a puzzle. If the player drops the carrot here, 
                // the wombat comes out of kennel and eats carrot (once you've coded this!).
                return "If you want the wombat to come out, you'll have to do some coding first!!!!";
            } else
                return "";
        }


        // TODO: Consider providing Actor class with a property called ThingsInRoom so that this code
        // can call 
        //      adv.Player.ThingsInRoom 
        // instead of 
        //      adv.Player.CurrentRoom.Things
        // Similarly, think about writing an Actor method such as getOb( anObject ) so that the code
        // can call
        //      adv.Player.getOb( obname )
        // instead of
        //      adv.Player.CurrentRoom.Things.thisOb( obname )
        // In short, if you notice that your code is becoming verbose by 'chaining together' variables,
        // methods and properties, think of rewriting your class definitions to avoid this

        private string dropOb( string obname ) {
            Thing t = adv.Player.Things.thisOb( obname );
            if( t == null )
                return "You haven't got one!";
            else {
                transferOb( t, adv.Player.Things, adv.Player.CurrentRoom.Things );
                return t.Name + " dropped!" + dropObSpecialAction( t, adv.Player.CurrentRoom ); // check for any special actions ;
            }
        }

        private string lookAtOb( string obname ) {
            Thing t;
            if( obname == "" )
                return "You'll have to say what you want to look at!";
            else {
                t = adv.Player.CurrentRoom.Things.thisOb( obname );
                if( t == null )
                    t = adv.Player.Things.thisOb( obname );
                if( t == null )
                    return "There is no " + obname + " here!";
                else {
                    return t.Description + ".";
                }
            }
        }

        private void doLook( ) {
            showLocation( );
        }

        private void northBtn_Click( object sender, System.EventArgs e ) {
            movePlayer( Dir.NORTH );
        }

        private void southBtn_Click( object sender, System.EventArgs e ) {
            movePlayer( Dir.SOUTH );
        }

        private void westBtn_Click( object sender, System.EventArgs e ) {
            movePlayer( Dir.WEST );
        }

        private void eastBtn_Click( object sender, System.EventArgs e ) {
            movePlayer( Dir.EAST );
        }

        private void lookBtn_Click( object sender, System.EventArgs e ) {
            doLook( );
        }

        private void takeBtn_Click( object sender, System.EventArgs e ) {
            WrLn( takeOb( inputTB.Text ) );
        }

        private void dropBtn_Click( object sender, System.EventArgs e ) {
            WrLn( dropOb( inputTB.Text ) );
        }

        private void lookAtBtn_Click( object sender, System.EventArgs e ) {
            WrLn( lookAtOb( inputTB.Text ) );
        }

        private void SavemenuItem_Click( object sender, System.EventArgs e ) {
            Stream st;
            BinaryFormatter binfmt;
            if( saveFileDialog.ShowDialog( ) == DialogResult.OK ) {
                if( ( st = saveFileDialog.OpenFile( ) ) != null ) {
                    // Save to disk
                    binfmt = new BinaryFormatter( );
                    binfmt.Serialize( st, adv );
                    st.Close( );
                    WrLn( "Saved" );
                }
            }
        }

        private void LoadmenuItem_Click( object sender, System.EventArgs e ) {
            Stream st;
            BinaryFormatter binfmt;
            if( openFileDialog.ShowDialog( ) == DialogResult.OK ) {
                if( ( st = openFileDialog.OpenFile( ) ) != null ) {
                    binfmt = new BinaryFormatter( );
                    adv = (Adventure) binfmt.Deserialize( st );
                    st.Close( );
                }
            }
            displayTB.Clear( );
            doLook( );
        }

        private void RestartmenuItem_Click( object sender, System.EventArgs e ) {
            initAdventure( );
        }

        private void ExitmenuItem_Click( object sender, System.EventArgs e ) {
            Close( );
        }

        private void MainForm_Load( object sender, System.EventArgs e ) { // create adventure on loading
            initAdventure( );
        }

        private void invBtn_Click( object sender, System.EventArgs e ) {
            showInventory( );
        }

    }
}
