using System;
using System.Collections;
using System.Collections.Generic;

namespace game.gameclasses {
    /// <summary>
    /// AdventureThings contains a hierarchy of the
    /// essential object types of an adventure game
    /// such as Treasure, Room and Player
    /// </summary>
    ///

    /* Base classes that define the Things in this game */

    // ==========================================================
    // class Thing
    // ==========================================================
    [Serializable]
    public class Thing {   // the basic Thing from which all Adventure
        // objects descend.

        private string _name;
        private string _description;
        private bool _cantake;

        public Thing( string aName, string aDescription ) {
            // standard constructor: 
            _name = aName;
            _description = aDescription;
            _cantake = true; // sets _cantake to default value
        }

        public Thing( string aName, string aDescription, bool aCantake ) {
            // alternative constructor
            _name = aName;
            _description = aDescription;
            _cantake = aCantake;
        }

        public string Name   //  Name property
        {
            get {
                return _name;
            }
            set {
                _name = value;
            }
        }

        public string Description   // Description property
        {
            get {
                return _description;
            }
            set {
                _description = value;
            }
        }

        public bool CanTake {
            get {
                return _cantake;
            }
            set {
                _cantake = value;
            }
        }

        public virtual string describe( ) //!! note this is a virtual method
        {
            return Name + " " + Description;
        }


    } // Thing

    // ==========================================================
    // class ThingHolder
    // ==========================================================
    [Serializable]
    public class ThingHolder : Thing {
        private ThingList _things = new ThingList( );

        public ThingHolder( string aName, string aDescription, ThingList tl )
            : base( aName, aDescription ) {
            _things = tl;
        }

        public ThingHolder( string aName, string aDescription, bool aCanTake, ThingList tl )
            : base( aName, aDescription, aCanTake ) {
            _things = tl;
        }

        public ThingList Things {
            get {
                return _things;
            }
            set {
                _things = value;
            }
        }

        public void addThing( Thing aThing ) {
            _things.Add( aThing );
        }

        public void addThings( ThingList aThingList ) {
            _things.AddRange( aThingList );
        }

        public override string describe( ) {
            return String.Format( "Name: {0}, Description {1} - it contains ->", Name, Description ) + _things.describe( );

        }

    } // ThingHolder




}
