﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TaxCalc {
    public partial class Form1 : Form {
        public Form1( ) {
            InitializeComponent( );
        }

        /** 
         * This is another comment
         * It can span several lines
         * */

        // calculate and display tax and grandtotal based on subtotal
        private void calcBtn_Click( object sender, EventArgs e ) {
            const double TAXRATE = 0.2;     // a single-line comment
            double subtotal = Double.Parse( subtotalTB.Text ); 
            double tax = subtotal * TAXRATE;
            double grandtotal = subtotal + tax;
            int roundedTotal;
            taxTB.Text = tax.ToString( );
            grandTotalTB.Text = grandtotal.ToString( );
            roundedTotal = (int) grandtotal;
            this.Text = roundedTotal.ToString( );
        }
    }
}
