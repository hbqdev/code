﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DataTypes {
    public partial class Form1 : Form {
        public Form1( ) {
            InitializeComponent( );
        }

        private void button1_Click( object sender, EventArgs e ) {
            // These are constant value that can't be changed
            const string warning_msg = "Warning! Do not change! ";
            const double taxrate = 0.2;
            // These are variables - they can be changed
            string mystring = "Hello world";
            char mychar = '!';
            int myint = 100;
            int someotherint;
            double mydouble = 100.75;
            string msg = warning_msg + mystring + mychar;
            myint = 200;
            someotherint = myint * 2;
            textBox1.Text = msg;           
        }
    }
}
